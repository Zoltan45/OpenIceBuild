Version 1.25:

Added full sound rom layout to CMOS CPU board test.

Reimplemented Alexei Yashin as a secret character.
Needs tested.

Version 1.26

Added Sergei Makarov back to secret character roster.
Needs tested on hardware and MAME. Was commented out for
unknown reasons other than to prevent an unknown lock.  Needs tested.

Version 1.3

Typos fixed.

Please test with general gameplay and using the secret characters Sergei Makarov (S_M Jun 19) and Alexei Yashin (AVY Nov 5).
Most likely problems would be graphical, but be on the look out for anything really.

IPS patches work with lunar ips and Rompatcher.js